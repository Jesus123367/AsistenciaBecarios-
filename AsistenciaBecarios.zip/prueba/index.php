


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <title>Sistema de Asistencia CC UMT</title>


   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">

    <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed' rel='stylesheet' type='text/css'>

    <style>

     
      
      .specialHead{
        font-family: 'Oswald', sans-serif;
		color:#00F
      }

      .normalFont{
        font-family: 'Roboto Condensed', sans-serif;
		color:#FFF
      }
	  

      a {
        color: #FFFFFF;
        text-decoration: none;
      }

      a:link {
        color: #FFFFFF;
        text-decoration: none;
      }

      /* visited link */
      a:visited {
          color: #FFFFFF;
          text-decoration: none;
      }

      /* mouse over link */
      a:hover {
          color: #FFFFFF;
          text-decoration: none;
      }

      /* selected link */
      a:active {
          color: #FFFFFF;
          text-decoration: none;
      }
    </style>


 
  </head>
  <body>
	
	<div class="container" > 
  	<nav class="navbar navbar-default navbar-fixed-top navbar-inverse
    " role="navigation" style="background-color:#003">
      <div class="container">
        
        <div class="navbar-header">
       
          
          <a href="index.html" ><h1 class="normalFont">Unidad Multidisciplinaria Tizimin</h1></a>
          
  
       
    </nav>
    </div>
    
    <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <div class="jumbotron text-center text-block" style="padding-top:170px;">
              <img src="images/logo.jpg" height="250" alt="25">
                  <h1 class="specialHead" style="color:#003">SISTEMA DE ASISTENCIA DE BECARIOS CC</h1>
                  
      <h1> <a href="login.html" class="btn btn-primary btn-md specialHead" style="background-color:#003"> <span class="glyphicon glyphicon-tag" style="color:#FF0" style="background-size:auto"></span> Iniciar Sesión</a></h1>
            </div>
          </div>
        </div>
      </div>

</body>
</html>
