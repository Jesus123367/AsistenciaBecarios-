<?php 

 include 'conexion.php';

 $nombre = $_POST['nombre'];
 

 $borrar = "DELETE FROM usuarios WHERE nombre = '$nombre'";

 $resultado = mysqli_query($conexion, $borrar);


 if(!$resultado){
 	echo 'Error al ELIMINAR'; 

 	
 }else {
   echo 'Usuario ELIMINADO';
    header("Location: menuAdmin.html");
}




?>