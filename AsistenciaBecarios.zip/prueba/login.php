
<?php

 include 'conexion.php';
 session_start();

 if (isset($_POST['ingresar'])) {
 	 
$nombre = $_POST["txtnombre"];
 $pass = $_POST["txtpassword"];
 
$query = mysqli_query($conexion, "SELECT * FROM login WHERE usuario = '".$nombre."' and password= '".$pass."'");

//$resultado = mysqli_query($conexion, $query);

$nr = mysqli_num_rows($query);

        if ($nr == 1){
              header("Location: registro_entrada_salida.php");
         // echo "Bienvenido" .$nombre;
        }
          else if ($nr == 0) {
            echo "No ingresó";
          }

 }



?>


