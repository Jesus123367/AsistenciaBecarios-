<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbbase = "bd_centroc";


//conectar a la base de datos

$conexion = mysqli_connect($dbhost,$dbuser,$dbpass , $dbbase);
/*if (!$conexion) {
	echo "Error en la conexion";
}else

echo "conectado";*/



?> 