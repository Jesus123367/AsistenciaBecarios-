<?php 

 include 'conexion.php';

 if (isset($_REQUEST['ingresar'])) {
 	
 $fecha_entrada = $_POST['fechae'];
 

 $consulta = "INSERT INTO asistencia (entrada) VALUES ('$fecha_entrada')";

 $resultado = mysqli_query($conexion, $consulta);


 if(!$resultado){
 	echo '<script> alert ("Error al ingresar la fecha")</script>'; 

 	
 }else {
 	echo '<script> alert ("Fecha ingresada correctamente ")</script>'; 
 	header("Location: login.html");
    
}
 }

 if (isset($_REQUEST['ingresars'])) {
 	
 $fecha_salida = $_POST['fechas'];
 

 $consulta2 = "INSERT INTO asistencia (salida) VALUES ('$fecha_salida')";

 $resultado = mysqli_query($conexion, $consulta2);


 if(!$resultado){
 	echo '<script> alert ("Error al ingresar la fecha")</script>'; 

 	
 }else {
    header("Location: login.html");
   echo '<script> alert ("Fecha ingresada correctamente ")</script>'; 

}
 }




?>