<?php 

 include 'conexion.php';

 

// Extraemos el nombre y el email del registro con id = 3







 /*$nombre = $_POST['nombre'];
 $carrera = $_POST['carrera'];
 $plantel = $_POST['plantel'];
 $celular = $_POST['celular'];
 $programa = $_POST['programa'];
 $horas = $_POST['horas'];
 $inicio = $_POST['inicio'];
 $finalizacion = $_POST['finalizacion'];

 

 $modificar = "UPDATE usuarios SET nombre='$nombre', carrera='$carrera', plantel='$plantel',celular='$celular',programa='$programa', horas= '$horas',inicio= '$inicio',finalizacion ='$finalizacion'"; 
 $resultado = mysqli_query($conexion, $modificar);
 if(!$resultado){
 	echo 'Error al ACTUALIZAR'; 

 	
 }else {
   echo 'Usuario ACTUALIZADO';
}*/


 ?>



