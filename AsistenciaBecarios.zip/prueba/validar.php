<?php 

 include 'conexion.php';

 $nombre = $_POST['nombre'];
 $carrera = $_POST['carrera'];
 $plantel = $_POST['plantel'];
 $celular = $_POST['celular'];
 $programa = $_POST['programa'];
 $horas = $_POST['horas'];
 $inicio = $_POST['inicio'];
 $finalizacion = $_POST['finalizacion'];

 $insertar = "INSERT INTO usuarios (nombre, carrera, plantel,celular,programa, horas,inicio,finalizacion) VALUES ('$nombre ', '$carrera ' ,'$plantel', '$celular', '$programa','$horas', '$inicio','$finalizacion')"; 
 $resultado = mysqli_query($conexion, $insertar);
 if(!$resultado){
 	echo 'Error al registrarse'; 
 	 header("Location: menuAdmin.html");

 	
 }else {
    header("Location: menuAdmin.html");
}


 /*$conexion=mysqli_connect($dbhost,$dbuser,$dbpass , $dbbase);

 

 

 insertar = "INSERT INTO usuarios (nombre, carrera, plantel,celular,programa, horas,inicio,finalizacion) VALUES ('$nombre ', '$carrera ' ,'$plantel', '$celular', '$programa','$horas', '$inicio','$finalizacion ')"; 

 $resultado = mysqli_query($conexion, $insertar);
 if(!$resultado){
 	echo 'Error'; 

 	
 }else {
   echo 'Usuario registrado';
}
mysqli_close($conexion);*/

?>