<?php 

 include 'conexion.php';

 $nombre = $_POST["usuario"];
 $pass = $_POST["password"];
 

 $insertar1 = "INSERT INTO login (usuario, password) VALUES ('$nombre', '$pass')"; 
 $resultado = mysqli_query($conexion, $insertar1);
 if(!$resultado){


 	echo 'Error al registrarse'; 

 	
 }else {
 	  header("Location: login.html");
   //echo 'Becario registrado';
}


 /*$conexion=mysqli_connect($dbhost,$dbuser,$dbpass , $dbbase);

 

 

 insertar = "INSERT INTO usuarios (nombre, carrera, plantel,celular,programa, horas,inicio,finalizacion) VALUES ('$nombre ', '$carrera ' ,'$plantel', '$celular', '$programa','$horas', '$inicio','$finalizacion ')"; 

 $resultado = mysqli_query($conexion, $insertar);
 if(!$resultado){
 	echo 'Error'; 

 	
 }else {
   echo 'Usuario registrado';
}
mysqli_close($conexion);*/

?>